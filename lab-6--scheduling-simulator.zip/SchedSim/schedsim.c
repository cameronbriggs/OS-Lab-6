// Function to find the waiting time for all  
// processes using Round Robin scheduling
void findWaitingTimeRoundRobin(ProcessType plist[], int n, int quantum) 
{ 
    int rem_bt[n];
    for (int i = 0; i < n; i++) {
        rem_bt[i] = plist[i].bt;
        plist[i].wt = 0;
    }

    int t = 0; // Initialize time

    // Keep traversing the processes while all processes are not done
    while (1) {
        int done = 1; // Assume all processes are done

        // Traverse all processes
        for (int i = 0; i < n; i++) {
            // If burst time is greater than 0, process is not done
            if (rem_bt[i] > 0) {
                done = 0; // There is a pending process

                // If remaining burst time is greater than quantum
                if (rem_bt[i] > quantum) {
                    t += quantum; // Increase time by quantum
                    rem_bt[i] -= quantum; // Decrease remaining burst time
                } else {
                    t += rem_bt[i]; // Increase time by remaining burst time
                    plist[i].wt = t - plist[i].bt; // Calculate waiting time
                    rem_bt[i] = 0; // Process is done
                }
            }
        }

        // If all processes are done, break
        if (done == 1) 
            break;
    }
}

// Function to find the waiting time for all  
// processes using Shortest Job First (SJF) scheduling
void findWaitingTimeSJF(ProcessType plist[], int n)
{
    int remaining_time[n];
    int completed = 0, t = 0, min_process;

    // Copy burst times to remaining_time array
    for (int i = 0; i < n; i++) {
        remaining_time[i] = plist[i].bt;
    }

    // Continue until all processes are done
    while (completed < n) {
        min_process = -1;

        // Find the process with the minimum remaining time
        for (int i = 0; i < n; i++) {
            if (plist[i].art <= t && remaining_time[i] > 0) {
                if (min_process == -1 || remaining_time[i] < remaining_time[min_process]) {
                    min_process = i;
                }
            }
        }

        // If no process is found, move time to the next arrival
        if (min_process == -1) {
            t++;
        } else {
            // Process min_process is selected
            t += remaining_time[min_process];
            plist[min_process].wt = t - plist[min_process].bt - plist[min_process].art;
            remaining_time[min_process] = 0;
            completed++;
        }
    }
}


// Function to sort the Process acc. to priority
int compareByPriority(const void *this, const void *that)
{
    const ProcessType *a = (const ProcessType *)this;
    const ProcessType *b = (const ProcessType *)that;

    return a->pri - b->pri;
}

// Function to calculate average time 
void findAvgTimePriority(ProcessType plist[], int n) 
{
    // Sort the processes according to priority
    qsort(plist, n, sizeof(ProcessType), compareByPriority);

    // Calculate waiting time and turn around time
    findWaitingTime(plist, n);
    findTurnAroundTime(plist, n);

    // Display processes along with all details
    printf("\n*********\nPriority\n");
}

void findAvgTimeRR(ProcessType plist[], int n, int quantum) 
{ 
    findWaitingTimeRoundRobin(plist, n, quantum); 
    findTurnAroundTime(plist, n); 
    printf("\n*********\nRound Robin Quantum = %d\n", quantum);
}
